**INFO6150 Assignment 7**

Multiple sass files were created for different components and all were imported to a style.scss file

Sass variables were used for different colors across the page

Custom properties were used for giving th bubble height and width in the \_hero.scss file

Nesting was used in almost all the scss files for each different component

Interpolation was used for giving the position for the bubbles in the hero section

Placeholder selector was used for giving flex properties to different components like align-center

Mixins were used for giving common properties

Function was used for setting the position of the bubble on the hero section where the position was passed as a prop

Media queries were used to make the website responsive
